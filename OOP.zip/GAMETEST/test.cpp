#include "pch.h"
#include "../OOP/Character.h"
#include "../OOP/GameManager.h"
#include "../OOP/MpPotion.h"
#include "../OOP/BattleSystem.h"
#include "../OOP/FakeRandomProvider.h"
TEST(InventoryManagerTest, Item_Insert_Test)
{
	Inventory inventory;
	Item* item = new MpPotion(50);
	
	EXPECT_TRUE(inventory.InsertItem(move(item)));
	ASSERT_EQ(inventory.GetInventorySize(), 1);
}

TEST(InventoryManagerTest, Item_Use_Test)
{
	Inventory inventory;
	bool result = inventory.UseItem();

	ASSERT_EQ(result, true);
}

//  정상 케이스 
TEST(DamageCalculatorTest, NormalDamage)
{
    DamageCalculator dc;

    unsigned int pureDamage = 100;
    unsigned int bonusAttackPower = 50;
    unsigned int defensePower = 50;

    unsigned int result = dc.CalculateDamage(pureDamage, bonusAttackPower, defensePower);

    EXPECT_EQ(result, 100); // (100 + 50) - 50 = 100
}

//  보너스 공격력 0 
TEST(DamageCalculatorTest, NoBonusAttackPower)
{
    DamageCalculator dc;

    unsigned int result = dc.CalculateDamage(100, 0, 30);

    EXPECT_EQ(result, 70); // (100 + 0) - 30 = 70
}

//  방어력 0 
TEST(DamageCalculatorTest, NoDefense)
{
    DamageCalculator dc;

    unsigned int result = dc.CalculateDamage(100, 50, 0);

    EXPECT_EQ(result, 150); // (100 + 50) - 0 = 150
}

//  방어력 == 공격력 (데미지 0)
TEST(DamageCalculatorTest, DefenseEqualsAttack_ZeroDamage)
{
    DamageCalculator dc;

    unsigned int result = dc.CalculateDamage(100, 0, 100);

    EXPECT_EQ(result, 0); // 100 - 100 = 0
}

//  방어력 > 공격력 (언더플로우 위험) 
TEST(DamageCalculatorTest, DefenseGreaterThanAttack_ShouldNotUnderflow)
{
    DamageCalculator dc;

    unsigned int result = dc.CalculateDamage(50, 0, 100);

    // 현재 구현: 50 - 100 = 언더플로우
    // 기대값: 0 (음수 데미지는 없어야 함)
    EXPECT_EQ(result, 0);
}

TEST(TownManagerTest, Change_Character_Job_Test)
{
    TownManager tm;

    Character character;
    EXPECT_EQ(character.GetJob()->GetJobType(), JobType::NoState);

    tm.ChangeJob(character, 1);
    EXPECT_EQ(character.GetJob()->GetJobType(), JobType::Warrior);
    tm.ChangeJob(character, 2);
    EXPECT_EQ(character.GetJob()->GetJobType(), JobType::Mage);
}

TEST(DungeonExplorerTest, Encounter_WhenRollIsLow_ReturnsTrue)
{
    FakeRandomProvider a (39); // 40 <= 40, 조우 성공
    Character character;
    DungeonExplorer explorer(&a);

    EXPECT_TRUE(explorer.Explore(character));
}

TEST(DungeonExplorerTest, Encounter_WhenRollIsHigh_ReturnsFalse)
{
    FakeRandomProvider a(41); // 40 <= 40, 조우 성공
    Character character;
    DungeonExplorer explorer(&a);

    EXPECT_FALSE(explorer.Explore(character));
}

TEST(DungeonExplorerTest, Encounter_BoundaryValue)
{
    FakeRandomProvider a(40); // 40 <= 40, 조우 성공

    Character character;
    DungeonExplorer explorer(&a);

    EXPECT_TRUE(explorer.Explore(character)); // <= 이므로 true
}