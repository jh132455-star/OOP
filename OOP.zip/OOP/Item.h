#pragma once
#include "GameEnum.h"
//#include "Character.h"
class Character;
class Item
{
public:
    virtual void use(Character& character) = 0;
    virtual ItemType GetItemType() const = 0;
};