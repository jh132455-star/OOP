#include "WeaknessAttackJudge.h"

unsigned int WeaknessAttackJudge::Judge(ElementType attacker, ElementType defender)
{
    bool res = false;
    if (attacker == ElementType::Fire && defender == ElementType::Grass) res = true;
    if (attacker == ElementType::Water && defender == ElementType::Fire) res = true;
    if (attacker == ElementType::Grass && defender == ElementType::Earth) res = true;
    if (attacker == ElementType::Earth && defender == ElementType::Water) res = true;

    if (res == true)
        return 2;
    else
        return 1;
}