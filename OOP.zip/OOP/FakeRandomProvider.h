#pragma once
#include "IRandomProvider.h"

class FakeRandomProvider : public IRandomProvider {
   public:
    int fixedValue;
    FakeRandomProvider(int value) : fixedValue(value) {}
    int Next(int min, int max) override { return fixedValue; }
};