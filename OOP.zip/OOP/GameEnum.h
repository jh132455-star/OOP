#pragma once

enum class ElementType
{
    NoStatement,
    Fire,
    Water,
    Grass,
    Earth
};

enum class MonsterType
{
    Slime,
    Goblin,
    Dragon
};

enum class ItemType
{
    HpPotion,
    MpPotion,
    Weapon,
    Armor,
    SkillScroll
};

enum class UIType 
{
    Main,
    Town,
    DungeonSelect,
    DungeonExplorer,
    Battle,
    Shop,
    BuySkill
};

enum class JobType 
{ 
    NoState,
    Warrior, 
    Mage
};