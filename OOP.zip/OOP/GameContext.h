#pragma once
#include <iostream>
#include "Character.h"
#include "Monster.h"
#include "GameContext.h"
#include "DungeonExplorer.h"
#include "TownManager.h"
#include "BattleSystem.h"
#include "BattleUi.h"
#include "BuySkillUi.h"
#include "DungeonExplorerUI.h"
#include "DungeonSelectUi.h"
#include "MainUi.h"
#include "ShopUi.h"
#include "TownUi.h"

using namespace std;
class GameContext
{
public:
    unique_ptr<Character>character;
    std::unique_ptr<UserInterface> ui;

    BattleSystem battleSystem;
    DungeonExplorer dungeonExplorer;
    MonsterFactory monsterFactory;
    TownManager townManager;
};

