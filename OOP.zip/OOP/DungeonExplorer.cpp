﻿#include "DungeonExplorer.h"
#include "RealRandomProvider.h"
#include <iostream>

using namespace std;


DungeonExplorer::DungeonExplorer()
{ 
    rng = new RealRandomProvider(); 
}

DungeonExplorer::DungeonExplorer(IRandomProvider* rng) 
{ 
    this->rng = rng; 
}

void DungeonExplorer::EnterDungeon(MonsterType type)
{
    this->type = type;
}

bool DungeonExplorer::Explore(Character& character) {
    cout << "\n===Dungeon Exploration Start ===" << endl;

    if (character.IsDead()) {
        cout << "Character is dead. Exploration stopped." << endl;
    }

    if (TryEncounter()) {
        cout << "Encountered a Monster!" << endl;
        return true;
    }
    else {
        cout << "Nothing happened." << endl;
        return false;
    }

    return false;
}

MonsterType DungeonExplorer::GetDungeonType()
{
    return type;
}

bool DungeonExplorer::TryEncounter() 
{ 
    return rng->Next(1, 100) <= ENCOUNTER_PERCENT; 
}