#include "Inventory.h"

Inventory::Inventory()
{
    inventorySize = 10;
}

Inventory::Inventory(size_t inventorySize)
    : inventorySize(inventorySize)
{
}

bool Inventory::InsertItem(Item* item)
{
    unsigned int remainSlot = GetRemainSlot();

    if (remainSlot > 0)
    {
        inventory[item]++;
        return true;
    }
    return false;
}

bool Inventory::UseItem()
{
    //아이템을 사용한다.
    return false;
}

//ItemType Inventory::GetItem(Item type)
//{
//
//    return type; // ItemType 키만 있고 실제 포인터가 없음
//}

unsigned int Inventory::GetInventorySize() 
{
    return inventory.size();
}

size_t Inventory::GetRemainSlot()
{
    unsigned int totalCount = 0;
    for (auto& pair : inventory)
        totalCount += pair.second;

    size_t remainSize = inventorySize - totalCount;

    return remainSize;
}
