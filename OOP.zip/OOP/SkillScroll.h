#pragma once
#include "Item.h"
#include "Skill.h"
class SkillScroll : public Item
{
public:
	virtual void use(Character& character) = 0;
	virtual ItemType GetItemType() const = 0;
private:
	Skill skill;
};