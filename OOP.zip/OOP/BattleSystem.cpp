﻿#include "BattleSystem.h"
#include "Character.h"
#include "Monster.h"

//void BattleSystem::Battle(Character& character, Monster& monster)
//{
//	while (!character.IsDead() && !monster.IsDead())
//	{
//		unsigned int characterDamage = CalculateDamage(character.Attack(), character.GetBonusAttackPower(), monster.GetDefensePower(), character.GetElementType(), monster.GetElementType());
//			
//		monster.TakeDamage(characterDamage);
//
//		if (monster.IsDead())
//			break;
//
//		unsigned int monsterDamage = CalculateDamage(monster.Attack(), 0, character.GetDefensePower(), monster.GetElementType(), character.GetElementType());
//		character.TakeDamage(monsterDamage);
//	}
//
//	if (character.IsDead()) 
//	{
//		std::cout << "Character is Dead. Monster Win" << std::endl;
//	}
//	else 
//	{
//		//Drop템을 캐릭터가 가져가야됨.
//		auto dropList = monster.GetDropList();
//		character.AcquireItems(dropList);
//		character.AcquireExe(monster.GetExe());
//
//		std::cout << "Monster is Dead. Character Win" << std::endl;
//		std::cout << "경험치를 획득하였습니다. 획득한 경험치 : " << monster.GetExe() << std::endl;
//		std::cout << "캐릭터의 현재 경험치 : " << character.GetExe() << std::endl;
//	}
//}
unsigned int BattleSystem::PlayerAttack(Character& character)
{
	unsigned int damage = CalculateDamage(
		character.Attack(), character.GetBonusAttackPower(),
		currentMonster.GetDefensePower(),
		character.GetElementType(), currentMonster.GetElementType()
		);
	
	currentMonster.TakeDamage(damage);

	return damage;
}

unsigned int BattleSystem::PlayerSkillAttack(unsigned int slotNum, Character& character)
{
	if (!character.HasJob()) {
		std::cout << "No job assigned." << std::endl;
		return 0;
	}

	unsigned int currentMp = character.GetMp();
	unsigned int skillPower = character.GetJob()->UseSkill(slotNum, currentMp);
	if (skillPower == 0) return 0;

	unsigned int damage = CalculateDamage(
		skillPower, 0,
		currentMonster.GetDefensePower(),
		character.GetElementType(), currentMonster.GetElementType()
	);
	currentMonster.TakeDamage(damage);

	return damage;
}

void BattleSystem::MonsterAttack(Character& character)
{
	unsigned int damage = CalculateDamage(
		currentMonster.Attack(), 0,
		character.GetDefensePower(),
		currentMonster.GetElementType(), character.GetElementType()
	);
	character.TakeDamage(damage);
}

void BattleSystem::DoMonsterAction(Character& character)
{
	if (!currentMonster.IsDead())
		MonsterAttack(character);
}

void BattleSystem::CleanUpBattle()
{
}

void BattleSystem::SetMonster(Monster monster)
{
	currentMonster = monster;
}

void BattleSystem::ResolveBattle(Character& character)
{
	if (currentMonster.IsDead()) 
	{
		auto dropList = currentMonster.GetDropList();
		character.AcquireItems(dropList);
		character.AcquireExe(currentMonster.GetExe());

		std::cout << "Monster is Dead. Character Win" << std::endl;
		std::cout << "경험치를 획득하였습니다. 획득한 경험치 : " << currentMonster.GetExe() << std::endl;
		std::cout << "캐릭터의 현재 경험치 : " << character.GetExe() << std::endl;
	}
	else 
	{
		std::cout << "캐릭터가 사망하였습니다. 마을로 이동합니다" << currentMonster.GetExe() << std::endl;
	}
	
}

bool BattleSystem::IsBattleOver(Character& character)
{
	return currentMonster.IsDead() || character.IsDead();
}

unsigned int BattleSystem::CalculateDamage(unsigned int pureDamage, unsigned int bonusAttackPower, unsigned int defensePower, ElementType attackerType, ElementType defenderType)
{
    unsigned int finalAttackPower = damage.CalculateDamage(pureDamage, bonusAttackPower, defensePower);
    unsigned int weaknessMultipul = weaknessJudge.Judge(attackerType, defenderType);

	finalAttackPower *= weaknessMultipul;

	return finalAttackPower;
}