#include "IRandomProvider.h"
#include <random>
using namespace std;

class RealRandomProvider : public IRandomProvider {
   public:
    int Next(int min, int max) override {
        static mt19937 rng(random_device{}());
        uniform_int_distribution<int> dist(min, max);
        return dist(rng);
    }
};