// Job.cpp
#include "Job.h"
#include <iostream>
using namespace std;


unsigned int Job::UseSkill(unsigned int slotNum, unsigned int& currentMp)
{
    unsigned int mpCost = quickSlot[slotNum].GetMpCost();
    unsigned int damage = quickSlot[slotNum].GetPower();

    if (currentMp >= mpCost)
        return damage;
    return 0;
}

bool Job::LearnSkill( Skill& skill)
{
    if (skill.GetRequiredJobType() == this->jobType || skill.GetRequiredJobType() == JobType::NoState)
    {
        skills.push_back(skill);
        cout << "Learned skill: " << skill.GetName() << endl;
        return true;
    }
    return false;
}

void Job::deleteSkill(std::string skillName)
{
    auto it = find_if(skills.begin(), skills.end(),
        [&skillName](Skill& s) {
            return s.GetName() == skillName;
        });

    if (it == skills.end()) {
        cout << "Skill not found: " << skillName << endl;
        return;
    }

    // 퀵슬롯에서도 제거
    int skillId = it->GetId();
    for (auto qit = quickSlot.begin(); qit != quickSlot.end(); ) {
        if (qit->second.GetId() == skillId)
            qit = quickSlot.erase(qit);
        else
            ++qit;
    }

    skills.erase(it);
    cout << "Skill deleted: " << skillName << endl;
}


bool Job::AssignQuickSlot(unsigned int slot, int skillId)
{
    // 보유한 스킬인지 체크
    



    for (const Skill& s : skills) 
    {
        quickSlot[slot] = s;        
        return true;
    }
    
    return false;
}

Skill* Job::GetQuickSlot(unsigned int slot)
{
    auto it = quickSlot.find(slot);
    if (it == quickSlot.end()) {
        cout << "No skill assigned to slot " << slot << endl;
        return nullptr;
    }

    int skillId = it->second.GetId();
    for (Skill& s : skills) {
        if (s.GetId() == skillId)
            return &s;
    }
    return nullptr;
}

void Job::ShowSkillList() 
{
    cout << "\n=== Skill List ===" << endl;
    for (Skill& s : skills) {
        cout << "[" << s.GetId() << "] " << s.GetName()
            << " | MP: " << s.GetMpCost()
            << " | Power: " << s.GetPower() << endl;
    }
}

void Job::ShowQuickSlotList() 
{
    cout << "\n=== Quick Slot ===" << endl;
    for (auto& [slot, skill] : quickSlot) {
        cout << "Slot " << slot << " : Skill name " << skill.GetName() << endl;
    }
}

JobType Job::GetJobType() { return jobType; }

