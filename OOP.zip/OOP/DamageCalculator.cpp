#include "DamageCalculator.h"

unsigned int DamageCalculator::CalculateDamage(unsigned int pureDamage,
                                               unsigned int bonusAttackPower,
                                               unsigned int defensePower) {
    unsigned int damage = pureDamage + bonusAttackPower;

        if (defensePower >= damage) 
            return 0;  // 데미지 음수 방지


    damage -= defensePower;

    return damage;
}
