#pragma once
#include "UserInterface.h"


class ShopUi : public UserInterface
{
	virtual void ShowMenu() override;
    virtual UIType GetType() override;
    virtual bool ProcessInput(int choice, GameContext& context) override;
};

