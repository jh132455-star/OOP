#pragma once
#include "Job.h"
class Mage : public Job
{
};

