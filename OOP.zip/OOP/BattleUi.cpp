﻿#include "BattleUi.h"
#include "GameContext.h"
void BattleUi::ShowMenu()
{
	std::cout << "\n=== 교전 중 수행할 동작을 선택하세요 ===" << std::endl;
	std::cout << "1. 일반 공격" << std::endl;
	std::cout << "2. 스킬공격" << std::endl;
	std::cout << "3. 도망가기" << std::endl;
	std::cout << "선택: " <<endl;
}

UIType BattleUi::GetType()
{
	return UIType::Battle; }

bool BattleUi::ProcessInput(int choice, GameContext& context) 
{ 
	switch (choice) 
    {
    case 1:
        cout << "\n일반공격 수행." << endl;
        context.battleSystem.PlayerAttack(*context.character);
        if (context.battleSystem.IsBattleOver(*context.character))
        {
            context.battleSystem.ResolveBattle(*context.character);
            context.ui = make_unique<DungeonExplorerUI>();
            break;
        }
        context.battleSystem.DoMonsterAction(*context.character);
        break;
    case 2:
        cout << "\n스킬공격 수행" << endl;
        cout << "\n사용할 스킬 슬롯을 입력하세요 : " << endl;
        unsigned int skillSlot;
        cin >> skillSlot;
        context.battleSystem.PlayerSkillAttack(skillSlot, *context.character);
        if (context.battleSystem.IsBattleOver(*context.character))
        {
            context.battleSystem.ResolveBattle(*context.character);
            context.ui = make_unique<DungeonExplorerUI>();
            break;
        }
        context.battleSystem.DoMonsterAction(*context.character);
        break;
    case 3:
        cout << "\n마을로 도망간다" << endl;
        context.battleSystem.CleanUpBattle();
        context.ui = make_unique<TownUi>();
        break;
    default: cout << "잘못된 입력" << endl;
    }
    return true;  // 추가
}
