#pragma once
#include "Consumable.h"

class HpPotion : public Consumable
{
public:
    HpPotion(unsigned int amount);
    void use(Character& character) override;
    ItemType GetItemType() const override;

private:
    unsigned int amount;
};