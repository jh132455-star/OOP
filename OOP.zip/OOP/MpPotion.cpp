// MpPotion.cpp
#include "MpPotion.h"

MpPotion::MpPotion(unsigned int amount)
    : amount(amount)
{
}

void MpPotion::use(Character& character)
{
    ;
}

ItemType MpPotion::GetItemType() const
{
    return ItemType::MpPotion;
}