#pragma once
#include "SkillCapable.h"
#include "Skill.h"
#include <vector>
#include <map>
#include <string>

class Job : public SkillCapable
{
public:
    Job() = default;
    Job(const std::string& name, JobType type) : name(name), jobType(type){}
        
    virtual unsigned int UseSkill(unsigned int slotNum , unsigned int& currentMp) override;

    bool LearnSkill(Skill& skill);
    void deleteSkill(std::string skillName);
    bool AssignQuickSlot(unsigned int slot, int skillId);

    Skill* GetQuickSlot(unsigned int slot);

    void ShowSkillList();
    void ShowQuickSlotList();

    JobType GetJobType();

private:
    std::string name;
    JobType jobType = JobType::NoState;
    std::vector<Skill> skills;               // 보유 스킬
    std::map<unsigned int, Skill> quickSlot;   // 슬롯번호 → skillId
};