﻿#include "DungeonSelectUi.h"
#include "GameContext.h"

void DungeonSelectUi::ShowMenu()
{
	std::cout << "\n=== 입장을 원하는 던전을 선택하세요 ===" << std::endl;
	std::cout << "1. 슬라임 던전" << std::endl;
	std::cout << "2. 고블린 던전" << std::endl;
	std::cout << "3. 드래곤 던전" << std::endl;
	std::cout << "4. 마을로 돌아가기" << std::endl;
	std::cout << "5. 메인으로 돌아가기" << std::endl;
	std::cout << "선택: ";
}

UIType DungeonSelectUi::GetType()
{
	return UIType::DungeonSelect; }

bool DungeonSelectUi::ProcessInput(int choice, GameContext& context) 
{ 
	switch(choice)
    {
    case 1:
        cout << "슬라임 던전에 입장합니다" << endl;
        context.dungeonExplorer.EnterDungeon(MonsterType::Slime);
        context.ui = make_unique<DungeonExplorerUI>();
        //dungeonExplorer.Explore(*character);
        break;
    case 2:
        cout << "고블린 던전에 입장합니다" << endl;
        context.dungeonExplorer.EnterDungeon(MonsterType::Goblin);
        context.ui = make_unique<DungeonExplorerUI>();
        //dungeonExplorer.Explore(*character);
        break;
    case 3:
        cout << "드래곤 던전에 입장합니다" << endl;
        context.dungeonExplorer.EnterDungeon(MonsterType::Dragon);
        context.ui = make_unique<DungeonExplorerUI>();
        //dungeonExplorer.Explore(*character);
        break;
    case 4:
        cout << "\n마을로 돌아갑니다" << endl;
        context.ui = make_unique<TownUi>();
        break;
    case 5:
        cout << "\n메인화면으로 돌아갑니다" << endl;
        context.ui = make_unique<MainUi>();
        break;
    default: cout << "잘못된 입력" << endl;
        }
        return true;  // 추가
}
