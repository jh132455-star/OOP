#pragma once
#include "Item.h"

class Consumable : public Item
{
public:
    virtual void use(Character& character) = 0;
};