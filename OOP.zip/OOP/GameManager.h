#pragma once
#include "UserInterface.h"
#include "GameContext.h"
class GameManager
{
public:
	GameManager();
	void StartGame();
private:
	bool ProcessInput(int choice, GameContext& context);

	GameContext gameContext;
};