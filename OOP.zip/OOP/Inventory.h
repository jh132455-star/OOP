#pragma once
#include <map>
#include <iostream>

#include "Item.h"
class Inventory
{
public:
	Inventory();
	Inventory(size_t inventorySize);

	bool InsertItem(Item* item);
	bool UseItem();

	unsigned int GetInventorySize();

private:
	size_t GetRemainSlot();

	size_t inventorySize;
	std::map<Item*, size_t> inventory;  // 아이템 종류 : 개수
};