#include "SkillScroll.h"

void SkillScroll::use(Character& character)
{

}