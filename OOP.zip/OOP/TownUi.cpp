﻿// TownUi.cpp
#include "TownUi.h"
#include "GameContext.h"

void TownUi::ShowMenu() {
    cout << "\n=== 마을 ===" << endl;
    cout << "0. 직업 변경" << endl;
    cout << "1. 체력 50 회복" << endl;
    cout << "2. 던전으로" << endl;
    cout << "3. 메인화면으로" << endl;
    cout << "Select: ";
}

UIType TownUi::GetType() {
    return UIType::Town; }

bool TownUi::ProcessInput(int choice, GameContext& context) 
{
    switch (choice) {
    case 0:
        cout << "\n직업 변경." << endl;
        context.townManager.ChangeJob(*context.character);
        break;
    case 1:
        cout << "\n캐릭터의 체력이 회복되었습니다." << endl;
        context.townManager.EnterHospital(*context.character);
        break;
    case 2:
        cout << "\n던전으로 이동합니다" << endl;
        context.ui = make_unique<DungeonSelectUi>();
        break;
    case 3:
        cout << "\n메인화면으로 돌아갑니다" << endl;
        context.ui = make_unique<MainUi>();
        break;
    case 4:
        cout << "\n상점으로 이동합니다" << endl;
        context.ui = make_unique<ShopUi>();
        break;
    default: cout << "잘못된 입력" << endl;
    }

    return true;  // 추가
}
