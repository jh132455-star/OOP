#include "JobFactory.h"
#include "Warrior.h"
#include "Mage.h"

std::unique_ptr<Job> JobFactory::Create(JobType type) {
    switch (type) 
    {
    case JobType::Warrior:
    {
        std::unique_ptr<Job> job = std::make_unique<Job>("Warrior",JobType::Warrior);
        Skill basicskill(1, "WarriorBasicSkill", JobType::Warrior, 10, 200);
        job->LearnSkill(basicskill);
        return job;
    }
    case JobType::Mage:
    {
        std::unique_ptr<Job> job = std::make_unique<Job>("Mage", JobType::Mage);
        Skill basicskill(2, "MageBasicSkill", JobType::Mage, 20, 300);
        job->LearnSkill(basicskill);
        return job;
    }
    default:
        std::unique_ptr<Job> job = std::make_unique<Job>("NoState", JobType::NoState);
        return job;
    }
}