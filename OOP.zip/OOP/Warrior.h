#pragma once
#include "Job.h"

class Warrior : public Job {
public:
};