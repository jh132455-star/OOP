class IRandomProvider {
   public:
    virtual int Next(int min, int max) = 0;
    virtual ~IRandomProvider() = default;
};