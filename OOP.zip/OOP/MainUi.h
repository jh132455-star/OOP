#pragma once
#include "UserInterface.h"
class MainUi : public UserInterface
{
public:
	virtual void ShowMenu() override;
	virtual UIType GetType() override;
	virtual bool ProcessInput(int choice, GameContext& context) override;

    private:
        void GenerateCharacter(GameContext& context);

};

