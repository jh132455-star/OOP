﻿#include "BuySkillUi.h"
#include "GameContext.h"
using namespace std;

void BuySkillUi::ShowMenu()
{
	cout << "=== 구매를 원하는 스킬을 선택하세요 ===" << endl;
	cout << "1. 공통 스킬1" << endl;
	cout << "2. 공통 스킬2" << endl;
	cout << "3. Warrior 스킬2" << endl;
	cout << "4. Mage 스킬2" << endl;
	cout << "선택: ";
}

UIType BuySkillUi::GetType()
{
	return UIType::BuySkill; }

bool BuySkillUi::ProcessInput(int choice, GameContext& context) 
{ 
	cout << "1. 공통 스킬1" << endl;
    cout << "2. 공통 스킬2" << endl;
    cout << "3. Warrior 스킬2" << endl;
    cout << "4. Mage 스킬2" << endl;
    switch (choice)
    {
    case 1:
    {
        cout << "\n공통 스킬1을 구매합니다" << endl;
        //Skill skill(3, "공통 스킬1", JobType::NoState, 3, 20);
        //character->GetJob()->LearnSkill(skill);
        //character->TakeItem();
        context.ui = make_unique<ShopUi>();
        break;
    }
    case 2:
    {
        cout << "\n공통 스킬2을 구매합니다" << endl;
        //Skill skill(4, "공통 스킬2", JobType::NoState, 3, 20);
        //character->GetJob()->LearnSkill(skill);
        context.ui = make_unique<ShopUi>();
        break;
    }
    case 3:
    {
        cout << "\nWarrior 스킬2을 구매합니다" << endl;
    
        //Skill skill(3, "Warrior 스킬2", JobType::Warrior, 3, 20);
        //character->GetJob()->LearnSkill(skill);
        context.ui = make_unique<ShopUi>();
        break;
    }
    case 4:
    {
        cout << "\nMage 스킬2을 구매합니다" << endl;
        //Skill skill(3, "Mage 스킬2", JobType::Mage, 3, 20);
        //character->GetJob()->LearnSkill(skill);
        context.ui = make_unique<ShopUi>();
        break;
    }
    default: cout << "잘못된 입력" << endl;
    }
    return true;  // 추가
}
