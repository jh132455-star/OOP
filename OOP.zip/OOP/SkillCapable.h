#pragma once

class SkillCapable {
public:
    virtual unsigned int UseSkill(unsigned int slotNum, unsigned int& currentMp) = 0;
};