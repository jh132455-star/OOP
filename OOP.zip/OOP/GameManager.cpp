﻿#include "GameManager.h"
#include "MainUi.h"
#include "DungeonSelectUi.h"
#include "DungeonExplorerUI.h"
#include "TownUi.h"
#include "BattleUi.h"
#include "BuySkillUi.h"
#include "ShopUi.h"

GameManager::GameManager()
{
    this->gameContext.ui = std::make_unique<MainUi>();
}

void GameManager::StartGame()
{
    int choice;
    while (true) 
    {
        this->gameContext.ui->ShowMenu();
        cin >> choice;
        this->gameContext.ui->ProcessInput(choice, gameContext); 
    }
}

bool GameManager::ProcessInput(int choice, GameContext& context) 
{

    this->gameContext.ui->ProcessInput(choice,context);
 
    return true;
}