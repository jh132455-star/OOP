#pragma once
#include "GameEnum.h"

class WeaknessAttackJudge
{
public:
	WeaknessAttackJudge() =  default;
	unsigned int Judge(ElementType attacker, ElementType defender);
};

