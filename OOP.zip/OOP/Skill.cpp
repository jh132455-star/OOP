#include "Skill.h"

Skill::Skill(int id, std::string skillName, JobType type, unsigned int mpCost, unsigned int power) :skillId(id), name(skillName), requiredJob(type), mpCost(mpCost), power(power)
{
}
