#pragma once
#include <string>
#include "GameEnum.h"

class Skill 
{
public:
    Skill() = default;
    Skill(int id, std::string skillName, JobType job, unsigned int mpCost, unsigned int power);
    std::string GetName(){ return name; }
    int GetId() { return skillId; }
    unsigned int GetMpCost() { return mpCost; }
    unsigned int GetPower() { return power; }
    JobType GetRequiredJobType() { return requiredJob; }
private:
    std::string name;

    int skillId;
    JobType requiredJob;
    unsigned int mpCost;
    unsigned int power;
    unsigned int level;
};