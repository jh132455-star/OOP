﻿#include "DungeonExplorerUI.h"
#include "GameContext.h"

void DungeonExplorerUI::ShowMenu()
{
	std::cout << "\n=== 던전에서 수행할 동작을 선택하세요 ===" << std::endl;
	std::cout << "1. 던전 탐색" << std::endl;
	std::cout << "2. 마을로 돌아가기" << std::endl;
	std::cout << "3. 메인으로 돌아가기" << std::endl;
	std::cout << "선택: ";
}

UIType DungeonExplorerUI::GetType()
{
	return UIType::DungeonExplorer; }

bool DungeonExplorerUI::ProcessInput(int choice, GameContext& context) 
{ 
	switch (choice) 
    {
    case 1:
        cout << "\n던전 탐색." << endl;
        if (context.dungeonExplorer.Explore(*context.character))
        {
            context.battleSystem.SetMonster(
                context.monsterFactory.Create(context.dungeonExplorer.GetDungeonType()));
            context.ui = make_unique<BattleUi>();
        }
        break;
    case 2:
        cout << "\n마을로 돌아가기" << endl;
        context.ui = make_unique<DungeonSelectUi>();
        break;
    default: cout << "잘못된 입력" << endl;
        }
        return true;  // 추가
}
