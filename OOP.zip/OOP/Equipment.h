// Equipment.h
#pragma once
#include "Item.h"

class Equipment : public Item
{
public:
    virtual void use(Character& character) = 0;
    virtual ItemType GetItemType() const = 0;
};