// MpPotion.h
#pragma once
#include "Consumable.h"

class MpPotion : public Consumable
{
public:
    MpPotion(unsigned int amount);
    void use(Character& character) override;
    ItemType GetItemType() const override;

private:
    unsigned int amount;
};