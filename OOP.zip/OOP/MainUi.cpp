﻿#include "MainUi.h"
#include "GameContext.h"

void MainUi::ShowMenu()
{
	cout << "=== 원하는 동작을 선택하세요 ===" << endl;
	cout << "0. 캐릭터 생성" << endl;
	cout << "1. 마을 입장" << endl;
	cout << "2. 던전 입장" << endl;
	cout << "3. 종료" << endl;
	cout << "선택: ";
}

UIType MainUi::GetType()
{
	return UIType::Main; }

bool MainUi::ProcessInput(int choice, GameContext& context) 
{ 
	switch (choice) {
        case 0:
            GenerateCharacter(context);
            break;
		case 1: 
			context.ui = make_unique<TownUi>(); 
			break;
		case 2: 
			context.ui = make_unique<DungeonSelectUi>(); 
			break;
		case 3: 
			return false;
		default: cout << "잘못된 입력" << endl;
	}
        return true;  // 추가
}

void MainUi::GenerateCharacter(GameContext& context) 
{
    if (context.character == nullptr) 
	{
        cout << "\n캐릭터 생성 성공" << endl;
        cout << "\n";
        context.character = std::make_unique<Character>();
    }
}
