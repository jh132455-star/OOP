#pragma once
class DamageCalculator 
{
   public:
    unsigned int CalculateDamage(unsigned int pureDamage, unsigned int bonusAttackPower,
                                 unsigned int defensePower);

};
