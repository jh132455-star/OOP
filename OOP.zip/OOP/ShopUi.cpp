﻿#include "ShopUi.h"
#include "GameContext.h"

void ShopUi::ShowMenu()
{
    cout << "\n=== 마을 ===" << endl;
    cout << "\n체력 회복 포션 구매." << endl;
    cout << "\n마나 회복 포션 구매" << endl;
    cout << "\n스킬 구매." << endl;
    cout << "\n상점 떠나기" << endl;
    cout << "Select: ";;
}

UIType ShopUi::GetType()
{
    return UIType::Shop; }

bool ShopUi::ProcessInput(int choice, GameContext& context) 
{ 
    switch (choice) 
    {
    case 1:
        cout << "\n체력 회복 포션을 구매합니다." << endl;
        break;
    case 2:
        cout << "\n마나 회복 포션을 구매합니다" << endl;
        break;
    case 3:
        cout << "\n스킬을 구매합니다." << endl;
        context.ui = make_unique<BuySkillUi>();
        break;
    case 4:
        cout << "\n상점을 떠납니다." << endl;
        context.ui = make_unique<TownUi>();
    default: cout << "잘못된 입력" << endl;
    }
    return true;  // 추가
}
