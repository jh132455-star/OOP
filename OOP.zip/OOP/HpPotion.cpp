#include "HpPotion.h"

HpPotion::HpPotion(unsigned int amount)
    : amount(amount)
{
}

void HpPotion::use(Character& character)
{
}

ItemType HpPotion::GetItemType() const
{
    return ItemType::HpPotion;
}