#pragma once
#include <iostream>
#include "GameEnum.h"
using namespace std;
class GameContext;  // 전방 선언으로 변경

class UserInterface
{
public:
	virtual void ShowMenu() = 0;
	virtual UIType GetType() = 0;
	virtual bool ProcessInput(int choice, GameContext& context) = 0;
};